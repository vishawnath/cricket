<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\country;
use App\players;
use App\fixtures;
use App\points;
use Illuminate\Database\QueryException;

class CricketController extends Controller
{
	/**
	* @desc country list.
	*/
    public function index()
    {
		try {
			$data = country::all();
			return response()->json(['Data' => $data, 'Message' => 'List.', 'message_code' => 200], 200);
		} catch (\Exception $E) {
            return response()->json(['Message' => 'Something went wrong.', 'Data' => '', 'MessageCode' => 400], 400);
        }
    }
	
	/**
	* @desc Player list by countryid
	*/
	public function playerlist($countryid)
    {
		try{
			$data = players::where('country', '=',$countryid)->get();
			return response()->json(['Data' => $data, 'Message' => 'List.', 'message_code' => 200], 200);
		} catch (\Exception $E) {
            return response()->json(['Message' => 'Something went wrong.', 'Data' => '', 'MessageCode' => 400], 400);
        }	
    }
	
	/**
	* @desc Player details
	*/
	public function playerdetails($playerid)
    {
		try{
			$data = players::where('id', '=',$playerid)->first();
			return response()->json(['Data' => $data, 'Message' => 'Player details.', 'message_code' => 200], 200);
		} catch (\Exception $E) {
            return response()->json(['Message' => 'Something went wrong.', 'Data' => '', 'MessageCode' => 400], 400);
        }
    }
	
	/**
	* @desc fixtures details
	*/
	public function fixtures()
    {
		try{
			$data = fixtures::with('country')->with('country2')->get();
			return response()->json(['Data' => $data, 'Message' => 'Player details.', 'message_code' => 200], 200);
		} catch (\Exception $E) {
            return response()->json(['Message' => 'Something went wrong.', 'Data' => '', 'MessageCode' => 400], 400);
        }
    }
	/**
	* @desc points
	*/
	public function points()
    {
		try{
			$data = points::all();
			return response()->json(['Data' => $data, 'Message' => 'Player details.', 'message_code' => 200], 200);
		} catch (\Exception $E) {
            return response()->json(['Message' => 'Something went wrong.', 'Data' => '', 'MessageCode' => 400], 400);
        }	
    }
}
