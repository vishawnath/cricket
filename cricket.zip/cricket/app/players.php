<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class players extends Model
{
    protected $table = 'players';
    public $timestamps = false;
    protected $primaryKey = 'id';
}
