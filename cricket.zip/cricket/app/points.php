<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class points extends Model
{
    protected $table = 'points';
    public $timestamps = false;
    protected $primaryKey = 'id';
}
