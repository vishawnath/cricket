<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class fixtures extends Model
{
    protected $table = 'fixtures';
    public $timestamps = false;
    protected $primaryKey = 'id';
	
	public function country()
    {
        return $this->belongsTo('App\country','team1','id');
    }
	
	public function country2()
    {
        return $this->belongsTo('App\country','team2','id');
    }
}
