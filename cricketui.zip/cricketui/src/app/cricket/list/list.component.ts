import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

	countrylist:any = [];

	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { }

	ngOnInit() {
		this.getData();
	}

	getData() {
		this.countrylist = [];
		this.rest.get('list').subscribe((data) => {
			this.countrylist = data.Data;
		});
	}

}
