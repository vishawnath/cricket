import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-players',
  templateUrl: './players.component.html',
  styleUrls: ['./players.component.css']
})
export class PlayersComponent implements OnInit {

  playerdetails:any = [];

	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { }

	ngOnInit() {
		this.getData();
	}

	getData() {
		this.playerdetails = [];
		this.rest.get('playerdetails/'+this.route.snapshot.params['Id']).subscribe((data) => {
			this.playerdetails = data.Data;
		});
	}

}
