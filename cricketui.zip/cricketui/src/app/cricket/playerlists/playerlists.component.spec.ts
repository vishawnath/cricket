import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerlistsComponent } from './playerlists.component';

describe('PlayerlistsComponent', () => {
  let component: PlayerlistsComponent;
  let fixture: ComponentFixture<PlayerlistsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayerlistsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayerlistsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
