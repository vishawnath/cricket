import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-playerlists',
  templateUrl: './playerlists.component.html',
  styleUrls: ['./playerlists.component.css']
})
export class PlayerlistsComponent implements OnInit {

	Playerlists:any = [];

	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { }

	ngOnInit() {
		this.getProducts();
	}

	getProducts() {
		this.Playerlists = [];
		this.rest.get('playerlist/'+this.route.snapshot.params['Id']).subscribe((data) => {
			this.Playerlists = data.Data;
		});
	}

}
