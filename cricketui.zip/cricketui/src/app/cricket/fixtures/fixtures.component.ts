import { Component, OnInit } from '@angular/core';
import { RestService } from '../../service/rest.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-fixtures',
  templateUrl: './fixtures.component.html',
  styleUrls: ['./fixtures.component.css']
})
export class FixturesComponent implements OnInit {

	fixtures:any = [];

	constructor(public rest:RestService, private route: ActivatedRoute, private router: Router) { }

	ngOnInit() {
		this.getData();
	}

	getData() {
		this.fixtures = [];
		this.rest.get('fixtures').subscribe((data) => {
			this.fixtures = data.Data;
		});
	}

}
