import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RestService } from './service/rest.service';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './cricket/list/list.component';
import { PlayersComponent } from './cricket/players/players.component';
import { PlayerlistsComponent } from './cricket/playerlists/playerlists.component';
import { FixturesComponent } from './cricket/fixtures/fixtures.component';
import { PointsComponent } from './cricket/points/points.component';

@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    PlayersComponent,
    PlayerlistsComponent,
    FixturesComponent,
    PointsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
	HttpClientModule
  ],
  providers: [
	RestService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
