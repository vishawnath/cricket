import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListComponent } from './cricket/list/list.component';
import { PlayersComponent } from './cricket/players/players.component';
import { PlayerlistsComponent } from './cricket/playerlists/playerlists.component';
import { FixturesComponent } from './cricket/fixtures/fixtures.component';
import { PointsComponent } from './cricket/points/points.component';

const routes: Routes = [
	{ path: '', component: ListComponent},
	{ path: 'playerlists/:Id', component: PlayerlistsComponent},
	{ path: 'playerdetails/:Id', component: PlayersComponent},
	{ path: 'fixtures', component: FixturesComponent},
	{ path: 'points', component: PointsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
