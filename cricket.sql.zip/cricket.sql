-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2019 at 06:23 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cricket`
--

-- --------------------------------------------------------

--
-- Table structure for table `country`
--

CREATE TABLE `country` (
  `id` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `logoUri` text NOT NULL,
  `clubstate` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `country`
--

INSERT INTO `country` (`id`, `name`, `logoUri`, `clubstate`) VALUES
(1, 'Australia', 'https://ulinkremit.com/wp-content/uploads/2017/11/australia_shadow_100.png', 0),
(2, 'India', 'https://www.thermbond.com/wp-content/uploads/2018/09/thermbond-refractories-india-flag.png', 0),
(3, 'England', 'https://www.backpainhelp.com/media/resized/100x100/wysiwyg/regions/uk-flag.png', 0),
(4, 'New Zealand', 'https://cdn.shopify.com/s/files/1/2074/1905/products/new-zealand-silver-fern-garden-flag-z1-one-size-large-28-x-40-red-flags-1sttheworld_319_small.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `fixtures`
--

CREATE TABLE `fixtures` (
  `id` int(11) NOT NULL,
  `team1` int(11) NOT NULL,
  `team2` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `location` text NOT NULL,
  `point` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fixtures`
--

INSERT INTO `fixtures` (`id`, `team1`, `team2`, `date`, `time`, `location`, `point`) VALUES
(1, 1, 2, '2019-07-24', '09:00:00', 'Delhi', 2),
(2, 2, 4, '2019-07-26', '10:00:00', 'Kolkata', 1);

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `id` int(10) NOT NULL,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `imageUri` text NOT NULL,
  `jerseyNumber` int(10) NOT NULL,
  `country` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `firstName`, `lastName`, `imageUri`, `jerseyNumber`, `country`) VALUES
(1, 'Aaron', 'Finch', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAMAAAAp4XiDAAAAk1BMVEUSEhLs0pvz4rvv16EQEBDx3bENDQ7w2qv////y4Lb15cIPDw/39/f87sl7enm4o3UUFRXn5+cHCArLy8s3Nzc9PTywmGRxaFWThmmpj1f74KTdxZHHsH6GdVPPuIf85bKdhE9EPC+noZNkWkf+67woKCcfHh3fzqdNS0cwLCVbSzQkIh03MyrMwKQuLi/l2LkbGBLzz8sZAAAEEUlEQVRIiY2WiZKqOhCGA4E4oJAYhYBssiou6Ps/3e0sgGPdqjn/TEmS7i+ddBZAP1r7w5/aG1ekfg9iYoQrEYJ+yZnb2SQOKxIOjJBaJElStPUg7VsHOY7yHo5tAQZRE8KGcGeQkA1kpG6ltMmoqAfVNRlqQbONaacTYSzUSIMYGbJuY+RVlXspKW1ofoFuXNPsdtlAGGkksu8Z4slCgHHjul7lV5XtycqiLuGI9XtAGgZBLp77p7zLQBCEQT8tBBHd34TrdgLCtDu0iwDJO+8f5OewAJFC+OTbtu2Zf+9XaSnLoj8RdNwrRAT2PymAkRmkWRGI5wedbypd4K/tgDQGQcOl82cFQdA111ZX2msD9WA1Qs4UQqJA+4LxdWmSqxyp8hDcuSb5czbCM+IKUQ7BswnFNeoHBHvp8XxdLtbl9XzAZiVDH11FmDwBgk40kkAlHOubKKRgD+agzIIfKneqlGjrRwgdJwYBnhYxBQ/YWpTGNI7THOM8jWNZoxQMOU0LGsD8JXJkgJRxGqfXqKVxCo4xLTGopLIVqiKqz9BPCfNnCrm/AtsqS9ofe95mZVlmmYWtzQZ+MlVt+4ltaVlafvAaJomMfuBa+GSJgT1gPNhSAgSELWjI64G1ULBw4PcKmfwA3DCcrTg7zYS1cU0BgyWmErWw708KOfo+1OXZkgdkZlx3JvBG7jJXWvzgqJHAB8D15NbUFinPm2O4njLBYbN8XyMPiCIJueC26y6IesronrLI3mwzsPvrF7LRiG0bZLYoRGcsIk85ME/tVhVeuc6IYowJd0+z+mEgDTBkuADm+UNyDCunqU3Y6kKNkF5nTAnPfQOylI0FY7/XCFxJlc4m1guJN2lW2XaVxTNkLFUyHzFC8pO1CJ8ywQdaVfTOBaztajnlhDsacXhfLszJKt7ydi0Kecm+C2u1lHfumCgO4ncTB+Pkrm969NbPe2IW6pTfOVoQZ8udBDYm7MKa87Gub608bu2trkfObxkwJ5wgDi+DBXEczmuKq+wBDwvOTJqez2f5sGjNHzAjeEhiRmSYLYy8Th5c4BMG93T+g+4FGGr5ztl+I0RO9ybTHZ8XxTKDrXq5KQSZq29h4HKJYUZZei5uoOKcZjCLGGlAEQuyMBzREyShpOP7PdJSJooqwsT4QjRzpzI/JeQDlbJEB0N8IzJrhhlpBo5w5XFYqywelxiK+EA+mLuIywIceZHHov8iWATIlaGVUYnbjrdJIuPtQczMzagAue4QvMLRJ6OzTbRWwBAIXuPo5zB8MSbfWtsvgh0A2Qk2M2rrbL/krAAQYic/FfbRb+YD0zW0EtFef5AcrlBhv6FF6ANA18P82bMPJ6aF/l/aNoX79eNqt2/CP9Xsdx/fY5L6U7Pnf/h2encVeZCKAAAAAElFTkSuQmCC', 1, 1),
(2, 'Jason', 'Behrendorff', 'https://react.semantic-ui.com/images/avatar/small/steve.jpg', 2, 1),
(3, 'Alex', 'Carey', 'https://gamepedia.cursecdn.com/futuramaworldsoftomorrow_gamepedia_en/thumb/b/b9/Icon_Character_George_Takei.png/50px-Icon_Character_George_Takei.png?version=72e243960cb3b1c7f8af701c35555207', 3, 1),
(4, 'Nathan', 'Coulter-Nile', 'https://secure.gravatar.com/avatar/96d0a45d225c6a4b0212224af72db80d?s=50&r=g', 4, 1),
(5, 'Virat', 'Kohli', 'https://gamepedia.cursecdn.com/futuramaworldsoftomorrow_gamepedia_en/thumb/b/b9/Icon_Character_George_Takei.png/50px-Icon_Character_George_Takei.png?version=72e243960cb3b1c7f8af701c35555207', 11, 2),
(6, 'MS', 'Dhoni', 'https://react.semantic-ui.com/images/avatar/small/steve.jpg', 22, 2),
(7, 'Jasprit', 'Bumrah', 'https://gamepedia.cursecdn.com/futuramaworldsoftomorrow_gamepedia_en/thumb/b/b9/Icon_Character_George_Takei.png/50px-Icon_Character_George_Takei.png?version=72e243960cb3b1c7f8af701c35555207', 33, 2),
(8, 'Rohit', 'Sharma', 'https://secure.gravatar.com/avatar/96d0a45d225c6a4b0212224af72db80d?s=50&r=g', 44, 2),
(9, 'Eoin', 'Morgan', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUFUVNgzvUCYo6u0WaBSg8yfND-3yYfRkBcPcBHalV8CybdldPlw', 21, 3),
(10, 'Moeen', 'Ali', 'https://secure.gravatar.com/avatar/96d0a45d225c6a4b0212224af72db80d?s=50&r=g', 31, 3),
(11, 'Kane', 'Williamson', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUFUVNgzvUCYo6u0WaBSg8yfND-3yYfRkBcPcBHalV8CybdldPlw', 41, 4),
(12, 'Tom', 'Blundell', 'https://secure.gravatar.com/avatar/96d0a45d225c6a4b0212224af72db80d?s=50&r=g', 42, 4);

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE `points` (
  `id` int(11) NOT NULL,
  `countryname` varchar(255) NOT NULL,
  `points` int(11) NOT NULL,
  `win` int(11) NOT NULL,
  `loss` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `points`
--

INSERT INTO `points` (`id`, `countryname`, `points`, `win`, `loss`) VALUES
(1, 'India', 12, 7, 1),
(2, 'England', 4, 3, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fixtures`
--
ALTER TABLE `fixtures`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fixtures`
--
ALTER TABLE `fixtures`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `points`
--
ALTER TABLE `points`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
